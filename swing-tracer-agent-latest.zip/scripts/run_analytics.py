"""Analytics Runner

Generate performance analytics from backtest summaries.  This script reads
the latest JSON file produced by ``run_backtest.py`` (located in the
``backtests/`` directory), computes key statistics (win rate, average
win/loss, expectancy, profit factor, number of trades per ticker and
theme), and writes a Markdown report to ``reports/analytics_report.md``.

Usage:
    python scripts/run_analytics.py

This script is intended as a post‑processing tool for backtesting and
live trading logs.  It operates purely on files and does not perform
network requests.
"""

from __future__ import annotations

import json
import statistics
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple


def load_latest_summary(backtests_dir: Path) -> List[Dict[str, object]]:
    """Load the most recent backtest summary file.

    Args:
        backtests_dir: directory containing backtest summary JSON files.

    Returns:
        List of summary entries (each a dict per ticker) or empty list.
    """
    files = sorted(backtests_dir.glob("backtest_summary_*.json"))
    if not files:
        return []
    latest = files[-1]
    data = json.loads(latest.read_text(encoding="utf-8"))
    return data


def compute_metrics(trades_by_ticker: Dict[str, List[Dict[str, object]]]) -> Dict[str, object]:
    """Compute aggregate statistics from trade records.

    Args:
        trades_by_ticker: mapping from ticker to list of trade dicts.

    Returns:
        Dictionary of aggregate metrics.
    """
    all_trades: List[Dict[str, object]] = []
    for trades in trades_by_ticker.values():
        all_trades.extend(trades)
    if not all_trades:
        return {}
    profits = [t["profit"] for t in all_trades]
    wins = [p for p in profits if p > 0]
    losses = [p for p in profits if p <= 0]
    num_trades = len(profits)
    win_rate = len(wins) / num_trades if num_trades else 0
    loss_rate = len(losses) / num_trades if num_trades else 0
    avg_win = statistics.mean(wins) if wins else 0.0
    avg_loss = statistics.mean(losses) if losses else 0.0
    expectancy = win_rate * avg_win + loss_rate * avg_loss
    sum_wins = sum(wins) or 1.0
    sum_losses = -sum(losses) or 1.0
    profit_factor = sum_wins / sum_losses
    return {
        "number_of_trades": num_trades,
        "win_rate": round(win_rate, 3),
        "avg_win": round(avg_win, 2),
        "avg_loss": round(avg_loss, 2),
        "expectancy": round(expectancy, 2),
        "profit_factor": round(profit_factor, 2),
    }


def load_trades(backtests_dir: Path) -> Dict[str, List[Dict[str, object]]]:
    """Load the most recent backtest trades file.

    Args:
        backtests_dir: directory containing backtest trade JSON files.

    Returns:
        Dict mapping tickers to lists of trade dicts.
    """
    files = sorted(backtests_dir.glob("backtest_trades_*.json"))
    if not files:
        return {}
    latest = files[-1]
    data = json.loads(latest.read_text(encoding="utf-8"))
    return data


def build_report(summary: List[Dict[str, object]], metrics: Dict[str, object]) -> str:
    """Construct a Markdown report from summary and metrics.

    Args:
        summary: list of per‑ticker summaries.
        metrics: aggregate metrics.

    Returns:
        Markdown string.
    """
    lines = []
    today = datetime.utcnow().strftime("%Y-%m-%d")
    lines.append(f"# Analytics Report — {today}\n")
    if not summary:
        lines.append("No backtest summary found.")
        return "\n".join(lines)
    lines.append("## Aggregate Metrics")
    lines.append(f"- Number of trades: {metrics['number_of_trades']}")
    lines.append(f"- Win rate: {metrics['win_rate']*100:.1f}%")
    lines.append(f"- Average win: {metrics['avg_win']}")
    lines.append(f"- Average loss: {metrics['avg_loss']}")
    lines.append(f"- Expectancy: {metrics['expectancy']}")
    lines.append(f"- Profit factor: {metrics['profit_factor']}")
    lines.append("")
    lines.append("## Per‑Ticker Summary")
    for row in summary:
        lines.append(f"- **{row['ticker']}** ({row['theme']}): total profit {row['total_profit']:.2f}, win rate {row['win_rate']:.3f}")
    return "\n".join(lines)


def run() -> None:
    root = Path(__file__).resolve().parents[1]
    backtests_dir = root / "backtests"
    summary = load_latest_summary(backtests_dir)
    trades_by_ticker = load_trades(backtests_dir)
    metrics = compute_metrics(trades_by_ticker)
    report_md = build_report(summary, metrics)
    out_dir = root / "reports"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "analytics_report.md"
    out_path.write_text(report_md, encoding="utf-8")
    print(f"Analytics report written to {out_path}")


if __name__ == "__main__":
    run()