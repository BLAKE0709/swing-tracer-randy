"""Backtest Runner

This script runs a simple backtest across the swing‑trader universes using
the `backtester` module.  It loads the same configuration files used by
the daily signal generator, fetches historical price data (via the live
data module) and applies the signal engine to each ticker.  The
resulting trades are summarized and written to a JSON report.

Usage
-----
```
python scripts/run_backtest.py
```

This will write a summary file to ``backtests/`` in the project root.

Note:  The backtest currently uses the `signal_engine.generate_signal` function
to decide when to enter a trade.  Positions are sized according to
1.5 % risk with a 2× ATR stop.  Trades are held until either the stop
or 10 % target is hit, or the end of the data window.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, List

import pandas as pd

import sys

# Ensure the project root is on sys.path so that 'src' can be imported.
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src import live_data, signal_engine, backtester


def load_universe_configs(config_dir: Path) -> Dict[str, List[str]]:
    """Load universe CSV files into a dict mapping theme to tickers."""
    universes: Dict[str, List[str]] = {}
    for csv_file in sorted(config_dir.glob("*.csv")):
        theme = csv_file.stem
        tickers = []
        with open(csv_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    tickers.append(line.split(",")[0])
        if tickers:
            universes[theme] = tickers
    return universes


def run() -> None:
    root = Path(__file__).resolve().parents[1]
    config_dir = root / "config" / "universes"
    universes = load_universe_configs(config_dir)
    summary_list: List[Dict[str, Any]] = []
    trades_by_ticker: Dict[str, List[Dict[str, Any]]] = {}

    # Use roughly one year of data.  The backtester fetches 600 trading days,
    # so we do not need explicit date range here.
    for theme, tickers in universes.items():
        for ticker in tickers:
            # Run the backtest for this individual ticker by creating a single-item universe
            uni = {theme: [ticker]}
            result = backtester.run_backtest(uni, equity=100000.0, risk_pct=0.015)
            trades = result.pop("trades", [])
            trades_by_ticker[ticker] = trades
            summary_list.append({
                "ticker": ticker,
                "theme": theme,
                "win_rate": result.get("win_rate", 0),
                "total_profit": result.get("total_profit", 0),
                "starting_equity": result.get("starting_equity", 0),
                "ending_equity": result.get("ending_equity", 0),
            })

    # Write out summary and trades
    out_dir = root / "backtests"
    out_dir.mkdir(parents=True, exist_ok=True)
    today_str = datetime.utcnow().strftime("%Y%m%d")
    with open(out_dir / f"backtest_summary_{today_str}.json", "w", encoding="utf-8") as f:
        json.dump(summary_list, f, indent=2)
    with open(out_dir / f"backtest_trades_{today_str}.json", "w", encoding="utf-8") as f:
        json.dump(trades_by_ticker, f, indent=2)
    print(f"Backtest complete. {len(summary_list)} tickers processed.")


if __name__ == "__main__":
    run()