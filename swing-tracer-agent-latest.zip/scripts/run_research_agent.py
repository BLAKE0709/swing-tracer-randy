"""Research Agent Runner

This script orchestrates the research agent for the Swing Trader.  It
loads the universes, calls the research functions for each ticker, and
writes a simple Markdown report summarizing email subjects, Drive
documents, and a sentiment score.  The report is saved in
``reports/research_report.md``.

Usage:
    python scripts/run_research_agent.py

Note: Actual email and document searches will only return results if
appropriate connectors (e.g. Gmail, Google Drive) are enabled and
authorized.  Otherwise, the lists will be empty and sentiment will
remain neutral.
"""

from __future__ import annotations

import sys
import os
from pathlib import Path
from typing import List, Dict

# Ensure project root is on sys.path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.research_agent import compile_research_for_ticker


def load_universe_configs(config_dir: Path) -> Dict[str, List[str]]:
    """Load universe CSV files into a dict mapping theme to tickers."""
    universes: Dict[str, List[str]] = {}
    for csv_file in sorted(config_dir.glob("*.csv")):
        theme = csv_file.stem
        tickers = []
        with open(csv_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    tickers.append(line.split(",")[0])
        if tickers:
            universes[theme] = tickers
    return universes


def run() -> None:
    root = Path(__file__).resolve().parents[1]
    config_dir = root / "config" / "universes"
    universes = load_universe_configs(config_dir)
    all_reports: List[Dict[str, object]] = []
    for theme, tickers in universes.items():
        for ticker in tickers:
            report = compile_research_for_ticker(ticker)
            report["theme"] = theme
            all_reports.append(report)
    # Compose Markdown report
    lines: List[str] = []
    lines.append(f"# Research Report — {Path(__file__).stem}")
    lines.append("")
    for r in all_reports:
        lines.append(f"## {r['ticker']} ({r['theme']})")
        if r["email_subjects"]:
            lines.append("**Email snippets:**")
            for subj in r["email_subjects"]:
                lines.append(f"- {subj}")
        if r["drive_documents"]:
            lines.append("**Drive documents:**")
            for doc in r["drive_documents"]:
                lines.append(f"- {doc}")
        lines.append(f"**Sentiment score:** {r['sentiment']:+.2f}")
        lines.append("")
    out_dir = root / "reports"
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "research_report.md", "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"Research report written to {out_dir / 'research_report.md'}")


if __name__ == "__main__":
    run()