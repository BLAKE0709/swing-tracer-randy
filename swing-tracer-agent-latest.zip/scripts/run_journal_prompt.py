"""Journal Prompt Generator

This script creates a Markdown template to guide reflection after each trade.  When a
trade closes, run this script and specify a trade identifier (e.g. a ticker and date)
to generate a file under `reports/` with seven questions covering entry rules,
execution discipline, emotions, and lessons learned.  The file will be named
`trade_journal_{trade_id}.md` where `trade_id` is sanitized to remove spaces and
special characters.

Usage:
    python scripts/run_journal_prompt.py --trade-id NVDA_2025-01-15

This will write `reports/trade_journal_NVDA_2025-01-15.md` with a series of prompts.
Feel free to edit the prompts or add your own questions.  Journaling helps you
identify strengths and weaknesses in your process and supports continuous
improvement.
"""

import argparse
import re
from pathlib import Path


PROMPTS = [
    "1. What was the setup? Describe the technical or fundamental reason for entering the trade.",
    "2. Did you follow all entry criteria (trend, breakout, volume, RS, earnings blackout)? If you took an EOS override, why?",
    "3. How was your sizing and risk management? Were you comfortable with the position size?",
    "4. What happened during the trade? Note any emotions or external factors that influenced your decision making.",
    "5. How did you exit? Was it according to plan (partial at +10%, trailing stop, time stop)?",
    "6. What was the outcome (profit/loss)? How does it compare to expectations?",
    "7. What did you learn from this trade and how will you apply it going forward?",
]


def sanitize(text: str) -> str:
    """Sanitize the trade identifier to be filesystem-friendly."""
    return re.sub(r"[^a-zA-Z0-9_\-]", "_", text)


def create_journal(trade_id: str, reports_dir: Path) -> Path:
    reports_dir.mkdir(parents=True, exist_ok=True)
    sanitized = sanitize(trade_id)
    file_path = reports_dir / f"trade_journal_{sanitized}.md"
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(f"# Trade Journal — {trade_id}\n\n")
        for prompt in PROMPTS:
            f.write(f"{prompt}\n\n")
        f.write("\n")
    return file_path


def main():
    parser = argparse.ArgumentParser(description="Generate a trade journal template.")
    parser.add_argument("--trade-id", required=True, help="Identifier for the trade (e.g. NVDA_2025-01-15)")
    parser.add_argument("--project-root", default="..", help="Root directory of the project (default: parent of scripts)")
    args = parser.parse_args()

    root = Path(args.project_root)
    reports = root / "reports"
    path = create_journal(args.trade_id, reports)
    print(f"Journal created at {path}")


if __name__ == "__main__":
    main()