# Daily Signals — 2025-08-12 16:48 UTC

## Signals

- **NVDA** | theme: ai_compute | entry: 50.99 | stop: 46.89 | TP10: 56.09 | size: 365
  rationale: trend ok condition not met; breakout ok condition not met; volume ok condition not met; rs ok condition not met
- **AMD** | theme: ai_compute | entry: 50.81 | stop: 47.76 | TP10: 55.89 | size: 492
  rationale: trend ok condition not met; breakout ok condition not met; rs ok condition not met
- **AVGO** | theme: ai_compute | entry: 42.60 | stop: 38.91 | TP10: 46.86 | size: 405
  rationale: trend ok condition not met; breakout ok condition not met; volume ok condition not met; rs ok condition not met
- **SMCI** | theme: ai_compute | entry: 63.97 | stop: 59.74 | TP10: 70.36 | size: 354
  rationale: trend ok condition not met; volume ok condition not met; rs ok condition not met
- **ANET** | theme: ai_compute | entry: 55.40 | stop: 51.73 | TP10: 60.94 | size: 408
  rationale: trend ok condition not met; breakout ok condition not met; volume ok condition not met; rs ok condition not met
- **MSFT** | theme: ai_compute | entry: 119.78 | stop: 113.04 | TP10: 131.76 | size: 222
  rationale: breakout ok condition not met; volume ok condition not met; rs ok condition not met
- **GOOGL** | theme: ai_compute | entry: 40.15 | stop: 37.22 | TP10: 44.17 | size: 511
  rationale: trend ok condition not met; breakout ok condition not met; volume ok condition not met; rs ok condition not met
- **META** | theme: ai_compute | entry: 68.28 | stop: 62.95 | TP10: 75.11 | size: 281
  rationale: breakout ok condition not met; volume ok condition not met; rs ok condition not met
- **AAPL** | theme: ai_compute | entry: 77.09 | stop: 71.79 | TP10: 84.80 | size: 283
  rationale: trend ok condition not met; breakout ok condition not met; volume ok condition not met; rs ok condition not met
- **ORCL** | theme: ai_compute | entry: 63.17 | stop: 59.17 | TP10: 69.49 | size: 374
  rationale: trend ok condition not met; volume ok condition not met; rs ok condition not met
- **VRT** | theme: infra | entry: 54.92 | stop: 51.46 | TP10: 60.41 | size: 434
  rationale: trend ok condition not met; breakout ok condition not met; volume ok condition not met; rs ok condition not met
- **TT** | theme: infra | entry: 37.79 | stop: 34.59 | TP10: 41.56 | size: 469
  rationale: trend ok condition not met; breakout ok condition not met; volume ok condition not met; rs ok condition not met
- **CCJ** | theme: nuclear | entry: 105.43 | stop: 96.55 | TP10: 115.98 | size: 168
  rationale: breakout ok condition not met; volume ok condition not met; rs ok condition not met
- **RIVN** | theme: ev | entry: 44.54 | stop: 41.24 | TP10: 49.00 | size: 453
  rationale: trend ok condition not met; breakout ok condition not met; volume ok condition not met; rs ok condition not met

## Risk Summary

{
  "equity": 100000.0,
  "max_positions": 12,
  "open_risk_pct": 1.5
}