# Agentic Profit-First Swing Trader

**Goal:** +10% per trade within ~65 trading days, with partial at +10%, trail on remainder, strict 1.5% risk per trade, and max 12 concurrent positions.

This package contains a runnable skeleton you can expand. Replace the data stubs with your preferred data source, then schedule `python main.py` daily (EOD).

## Quick Start
1. Create a virtual environment and install dependencies you choose (e.g., `pip install yfinance pandas numpy`).
2. Edit `config/parameters.json` if desired.
3. Populate `data/earnings_calendar.csv` with up-to-date dates.
4. Run:
   ```bash
   python main.py
   ```
5. Check outputs in `signals/` and `reports/`.

## Where to plug in real logic
- **Data fetch:** Replace `stub_latest_price()` in `main.py` with real OHLCV pulls.
- **Signals:** Implement breakout + RS + volume checks in `utils/breakout_detector.py` & `utils/rs_filter.py`.
- **Sizing:** `utils/sizing.py` is ready; pass real entry/stop values.
- **Earnings:** Implement blackout override via `utils/earnings_filter.py` and `config/eos_rules.json`.
- **Reports:** `utils/report_generator.py` writes JSON + Markdown.

## Theme Universes
- Edit CSV files in `config/` to add/remove tickers:
  - `universe_ai_compute.csv` (LLM leaders included: NVDA, MSFT, GOOGL, etc)
  - `universe_infra.csv`
  - `universe_nuclear.csv`
  - `universe_ev.csv` (includes RIVN)

## Benchmarks
Mapped in `config/benchmarks.json` per theme (e.g., AI/Compute vs QQQ/SMH, Nuclear vs URNM/NLR, EV vs IWM/QQQ).

## Next Steps & Additional Features

This repository now includes several enhancements beyond the original skeleton:

- **Live data & backtesting** – The `src/live_data.py` module fetches OHLCV data via `yfinance` (falling back to a deterministic stub if the library is unavailable), while `src/backtester.py` and `scripts/run_backtest.py` let you run simulations across historical data to evaluate performance.
- **Risk management** – `src/risk_manager.py` adjusts per‑trade risk based on drawdown to help preserve capital during drawdowns.  It persists equity state in `data/risk_state.json`.
- **Research agent** – `src/research_agent.py` demonstrates how to search Gmail and Google Drive (via the API tool) and perform a simple sentiment analysis.  `scripts/run_research_agent.py` generates a markdown report summarising documents and email snippets by ticker.
- **Analytics dashboard** – Run `scripts/run_analytics.py` after a backtest to compute win rate, expectancy, profit factor, and more.  It writes a human‑readable report to `reports/analytics_report.md`.
- **Trade journaling** – Use `scripts/run_journal_prompt.py --trade-id <ID>` to generate a reflection template after each trade.  It creates a `trade_journal_<ID>.md` file under `reports/` with questions about setup, entry criteria, emotions, exit, outcome, and lessons learned.
- **Adaptive position sizing & alerts** – Core logic in `main.py` ties together the above modules to produce daily signals, orders, and reports.  It uses the risk manager to set position size, ensures no more than 12 concurrent trades, and writes logs for potential overrides.

### Suggested future improvements
These items remain as aspirational upgrades:

- **True live trading integration** – Connect to a broker API (e.g., Alpaca, Interactive Brokers) to place paper/live trades directly from the generated orders.
- **Advanced relative strength & factor rotation** – Rank tickers within each theme by RS and rotate into the top performers; incorporate sector and factor models for dynamic universe management.
- **Comprehensive research pipeline** – Extend the research agent to parse SEC filings, earnings transcripts, and press releases for deeper fundamental insights.
- **Dashboards & monitoring** – Automate generation of dashboards in Notion or other platforms to visualise performance and raise alerts if the daily run fails or drawdown thresholds are breached.
