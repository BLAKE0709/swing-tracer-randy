# Agentic Profit-First Swing Trader

**Goal:** +10% per trade within ~65 trading days, with partial at +10%, trail on remainder, strict 1.5% risk per trade, and max 12 concurrent positions.

This package contains a runnable skeleton you can expand. Replace the data stubs with your preferred data source, then schedule `python main.py` daily (EOD).

## Quick Start
1. Create a virtual environment and install dependencies you choose (e.g., `pip install yfinance pandas numpy`).
2. Edit `config/parameters.json` if desired.
3. Populate `data/earnings_calendar.csv` with up-to-date dates.
4. Run:
   ```bash
   python main.py
   ```
5. Check outputs in `signals/` and `reports/`.

## Where to plug in real logic
- **Data fetch:** Replace `stub_latest_price()` in `main.py` with real OHLCV pulls.
- **Signals:** Implement breakout + RS + volume checks in `utils/breakout_detector.py` & `utils/rs_filter.py`.
- **Sizing:** `utils/sizing.py` is ready; pass real entry/stop values.
- **Earnings:** Implement blackout override via `utils/earnings_filter.py` and `config/eos_rules.json`.
- **Reports:** `utils/report_generator.py` writes JSON + Markdown.

## Theme Universes
- Edit CSV files in `config/` to add/remove tickers:
  - `universe_ai_compute.csv` (LLM leaders included: NVDA, MSFT, GOOGL, etc)
  - `universe_infra.csv`
  - `universe_nuclear.csv`
  - `universe_ev.csv` (includes RIVN)

## Benchmarks
Mapped in `config/benchmarks.json` per theme (e.g., AI/Compute vs QQQ/SMH, Nuclear vs URNM/NLR, EV vs IWM/QQQ).

## Next Steps
- Integrate a real data API.
- Add portfolio-level backtesting (QuantConnect or custom Python backtester).
- Connect a paper broker API (IBKR/Alpaca) for hands-off validation.
- Tighten parameters by theme but avoid overfitting.
