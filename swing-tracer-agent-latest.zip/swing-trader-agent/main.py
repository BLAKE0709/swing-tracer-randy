"""Daily orchestration for the Agentic Profit-First Swing Trader.

This is a skeleton that:
1) loads configs
2) (placeholder) loads data
3) runs simple signal scaffolding
4) writes reports

Replace the data-loading stubs with your chosen data source (e.g., yfinance/Polygon/IBKR).

"""
import json, os
from pathlib import Path
from datetime import datetime
import pandas as pd

from utils.sizing import position_size
from utils.report_generator import save_daily_signals_json, save_daily_report_md

ROOT = Path(__file__).parent

def load_json(p): 
    with open(p, 'r') as f: 
        return json.load(f)

def load_universe():
    cfg = ROOT / "config"
    universes = {
        "ai_compute": (cfg / "universe_ai_compute.csv").read_text().strip().splitlines(),
        "infra": (cfg / "universe_infra.csv").read_text().strip().splitlines(),
        "nuclear": (cfg / "universe_nuclear.csv").read_text().strip().splitlines(),
        "ev": (cfg / "universe_ev.csv").read_text().strip().splitlines(),
    }
    return universes

def stub_latest_price(ticker:str) -> float:
    # TODO: replace with real price fetch
    # A harmless deterministic stub to allow the pipeline to run
    return float(abs(hash(ticker)) % 5000) / 100.0 + 10.0

def run():
    params = load_json(ROOT / "config/parameters.json")
    eos_rules = load_json(ROOT / "config/eos_rules.json")

    universes = load_universe()

    # In a real run, you'd gather OHLCV frames here.
    # We'll fabricate a single 'signal' per theme for demo purposes
    equity = 100_000.0
    risk_pct = params["risk_per_trade"]
    time_now = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

    signals = []
    for theme, tickers in universes.items():
        if not tickers: 
            continue
        t = tickers[0]
        entry = stub_latest_price(t)
        stop  = entry - 2.0  # pretend ATR*2
        tp10  = entry * 1.10
        size  = position_size(equity, entry, stop, risk_pct)

        signals.append({
            "ticker": t,
            "theme": theme,
            "benchmark": "AUTO",
            "action": "enter-long",
            "entry": round(entry,2),
            "initial_stop": round(stop,2),
            "tp_partial": round(tp10,2),
            "trail_rule": "6-8% off highest close",
            "size_shares": size,
            "risk_pct": risk_pct,
            "eos": 0,
            "earnings_date": None,
            "rationale": ["demo stub signal — replace with real calculations"],
            "constraints_check": ["liquidity_ok"]
        })

    # write outputs
    (ROOT / "signals").mkdir(exist_ok=True, parents=True)
    (ROOT / "reports").mkdir(exist_ok=True, parents=True)

    save_daily_signals_json(ROOT / "signals/daily_signals.json", signals)
    risk_summary = {"equity": equity, "max_positions": params["max_positions"], "open_risk_pct": risk_pct}
    save_daily_report_md(ROOT / "reports/daily_report.md", signals, risk_summary)

    print(f"[{time_now}] Wrote {len(signals)} demo signals to signals/daily_signals.json and reports/daily_report.md")

if __name__ == "__main__":
    run()
