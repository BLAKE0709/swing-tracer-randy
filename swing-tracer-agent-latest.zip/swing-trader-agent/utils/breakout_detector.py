import pandas as pd

def breakout_signal(df: pd.DataFrame, lookback:int=20, vol_mult:float=1.5) -> pd.Series:
    """df must contain columns: ['High','Low','Close','Volume']"""
    donch_hi = df['High'].rolling(lookback).max().shift(1)
    breakout = df['Close'] > donch_hi
    avg_vol = df['Volume'].rolling(20).mean()
    vol_ok = df['Volume'] > (vol_mult * avg_vol)
    return (breakout & vol_ok).fillna(False)
