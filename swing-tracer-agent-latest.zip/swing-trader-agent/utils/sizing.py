from typing import Tuple

def position_size(equity: float, entry: float, stop: float, risk_pct: float) -> int:
    """Return whole-share size based on risk percentage."""
    risk_amt = equity * (risk_pct/100.0)
    stop_dist = max(entry - stop, 1e-6)
    shares = int(risk_amt / stop_dist)
    return max(shares, 0)
