# Swing Signals — 2025-08-09


# Daily Signals — 2025-08-09 13:20 UTC

## Signals

- **NVDA** | theme: ai_compute | entry: 45.44 | stop: 43.44 | TP10: 49.98 | size: 750
  rationale: demo stub signal — replace with real calculations
- **VRT** | theme: infra | entry: 16.83 | stop: 14.83 | TP10: 18.51 | size: 750
  rationale: demo stub signal — replace with real calculations
- **CCJ** | theme: nuclear | entry: 26.60 | stop: 24.60 | TP10: 29.26 | size: 750
  rationale: demo stub signal — replace with real calculations
- **RIVN** | theme: ev | entry: 42.54 | stop: 40.54 | TP10: 46.79 | size: 750
  rationale: demo stub signal — replace with real calculations

## Risk Summary

{
  "equity": 100000.0,
  "max_positions": 12,
  "open_risk_pct": 1.5
}

---

## Signals JSON

```json
[
  {
    "ticker": "NVDA",
    "theme": "ai_compute",
    "benchmark": "AUTO",
    "action": "enter-long",
    "entry": 45.44,
    "initial_stop": 43.44,
    "tp_partial": 49.98,
    "trail_rule": "6-8% off highest close",
    "size_shares": 750,
    "risk_pct": 1.5,
    "eos": 0,
    "earnings_date": null,
    "rationale": [
      "demo stub signal \u2014 replace with real calculations"
    ],
    "constraints_check": [
      "liquidity_ok"
    ]
  },
  {
    "ticker": "VRT",
    "theme": "infra",
    "benchmark": "AUTO",
    "action": "enter-long",
    "entry": 16.83,
    "initial_stop": 14.83,
    "tp_partial": 18.51,
    "trail_rule": "6-8% off highest close",
    "size_shares": 750,
    "risk_pct": 1.5,
    "eos": 0,
    "earnings_date": null,
    "rationale": [
      "demo stub signal \u2014 replace with real calculations"
    ],
    "constraints_check": [
      "liquidity_ok"
    ]
  },
  {
    "ticker": "CCJ",
    "theme": "nuclear",
    "benchmark": "AUTO",
    "action": "enter-long",
    "entry": 26.6,
    "initial_stop": 24.6,
    "tp_partial": 29.26,
    "trail_rule": "6-8% off highest close",
    "size_shares": 750,
    "risk_pct": 1.5,
    "eos": 0,
    "earnings_date": null,
    "rationale": [
      "demo stub signal \u2014 replace with real calculations"
    ],
    "constraints_check": [
      "liquidity_ok"
    ]
  },
  {
    "ticker": "RIVN",
    "theme": "ev",
    "benchmark": "AUTO",
    "action": "enter-long",
    "entry": 42.54,
    "initial_stop": 40.54,
    "tp_partial": 46.79,
    "trail_rule": "6-8% off highest close",
    "size_shares": 750,
    "risk_pct": 1.5,
    "eos": 0,
    "earnings_date": null,
    "rationale": [
      "demo stub signal \u2014 replace with real calculations"
    ],
    "constraints_check": [
      "liquidity_ok"
    ]
  }
]
```

## Orders JSON

```json
[
  {
    "ticker": "NVDA",
    "side": "buy",
    "type": "market",
    "qty": 750,
    "limit_price": 0.0,
    "stop_price": 0.0,
    "time_in_force": "DAY",
    "notes": "sizing 1.5% risk; EOS override if any"
  },
  {
    "ticker": "VRT",
    "side": "buy",
    "type": "market",
    "qty": 750,
    "limit_price": 0.0,
    "stop_price": 0.0,
    "time_in_force": "DAY",
    "notes": "sizing 1.5% risk; EOS override if any"
  },
  {
    "ticker": "CCJ",
    "side": "buy",
    "type": "market",
    "qty": 750,
    "limit_price": 0.0,
    "stop_price": 0.0,
    "time_in_force": "DAY",
    "notes": "sizing 1.5% risk; EOS override if any"
  },
  {
    "ticker": "RIVN",
    "side": "buy",
    "type": "market",
    "qty": 750,
    "limit_price": 0.0,
    "stop_price": 0.0,
    "time_in_force": "DAY",
    "notes": "sizing 1.5% risk; EOS override if any"
  }
]
```