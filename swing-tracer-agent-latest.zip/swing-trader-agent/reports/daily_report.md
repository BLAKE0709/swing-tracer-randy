# Daily Signals — 2025-08-09 13:20 UTC

## Signals

- **NVDA** | theme: ai_compute | entry: 45.44 | stop: 43.44 | TP10: 49.98 | size: 750
  rationale: demo stub signal — replace with real calculations
- **VRT** | theme: infra | entry: 16.83 | stop: 14.83 | TP10: 18.51 | size: 750
  rationale: demo stub signal — replace with real calculations
- **CCJ** | theme: nuclear | entry: 26.60 | stop: 24.60 | TP10: 29.26 | size: 750
  rationale: demo stub signal — replace with real calculations
- **RIVN** | theme: ev | entry: 42.54 | stop: 40.54 | TP10: 46.79 | size: 750
  rationale: demo stub signal — replace with real calculations

## Risk Summary

{
  "equity": 100000.0,
  "max_positions": 12,
  "open_risk_pct": 1.5
}