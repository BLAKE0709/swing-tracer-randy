"""
Signal generation logic for the Swing Trader Agent.

This module computes entry signals based on common technical filters:
    - Trend filter: 50-day moving average above 200-day moving average.
    - Breakout filter: price closing above the previous 20-day high.
    - Volume filter: today's volume at least 1.5× the 20-day average volume.
    - Relative strength filter: the ratio of the ticker's price to its benchmark
      is above its 50-day moving average.
    - ATR-based stop and take profit levels.

The generated signal dictionary includes a rationale explaining which
conditions were met and a list of constraint checks for downstream consumers.

Constants:
    THEME_TO_BENCHMARK: mapping of theme names to their default benchmark symbols.

Functions:
    generate_signal(...): Compute a signal for a single ticker.
"""

from __future__ import annotations

from typing import Dict, List
import pandas as pd

from utils.rs_filter import rs_ratio

# Default benchmark symbols for each theme.  This mapping is used by both
# the daily signal runner and the backtester to select an appropriate
# relative strength benchmark.  You can modify these values to suit your
# preferred index or sector ETF.
THEME_TO_BENCHMARK = {
    "ai_compute": "QQQ",   # AI and compute leaders vs. Nasdaq
    "infra": "SPY",        # Infrastructure / utilities vs. S&P 500
    "nuclear": "URNM",     # Nuclear and uranium vs. uranium miners ETF
    "ev": "IWM",          # Electric/autonomy vs. Russell 2000
}
from utils.sizing import position_size

def _compute_atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """
    Compute the Average True Range (ATR) for a price series.

    Args:
        df: DataFrame with columns 'High', 'Low', 'Close'.
        period: lookback period for ATR.

    Returns:
        Pandas Series of ATR values.
    """
    tr1 = df["High"] - df["Low"]
    tr2 = (df["High"] - df["Close"].shift()).abs()
    tr3 = (df["Low"] - df["Close"].shift()).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    atr = tr.rolling(period).mean()
    return atr

def generate_signal(
    ticker: str,
    df: pd.DataFrame,
    benchmark_df: pd.DataFrame,
    equity: float,
    risk_pct: float
) -> Dict[str, object]:
    """
    Generate a single trading signal for ``ticker`` using OHLCV data.

    Args:
        ticker: symbol of the instrument.
        df: OHLCV DataFrame for the ticker.
        benchmark_df: OHLCV DataFrame for the benchmark index.
        equity: total account equity (used for sizing).
        risk_pct: fraction of equity to risk per trade (0 < risk_pct < 1).

    Returns:
        dict with signal details, or None if data is insufficient.
    """
    # require at least 200 periods for trend/RS calculations
    if len(df) < 200 or len(benchmark_df) < 200:
        return None
    # ensure indices align; reindex benchmark to ticker index
    bench = benchmark_df.reindex(df.index).dropna()
    if len(bench) < 200:
        return None

    price = df["Close"]
    vol = df["Volume"]

    # Trend: 50-d MA > 200-d MA
    ma50 = price.rolling(50).mean()
    ma200 = price.rolling(200).mean()
    trend_ok = bool(ma50.iloc[-1] > ma200.iloc[-1])

    # Breakout: Close > previous 20-day high
    twenty_high = df["High"].rolling(20).max()
    breakout_ok = bool(price.iloc[-1] > twenty_high.shift(1).iloc[-1])

    # Volume: Volume >= 1.5 * 20-day avg
    avg_vol20 = vol.rolling(20).mean()
    volume_ok = bool(vol.iloc[-1] >= 1.5 * avg_vol20.iloc[-1])

    # Relative strength: RS ratio > its 50-day moving average
    rs = rs_ratio(price, bench["Close"])
    rs_ma = rs.rolling(50).mean()
    rs_ok = bool(rs.iloc[-1] > rs_ma.iloc[-1])

    # ATR(14) for stop calculation
    atr_series = _compute_atr(df, period=14)
    atr = atr_series.iloc[-1]
    # compute entry, stop and TP10
    entry = float(price.iloc[-1])
    stop = float(entry - 2.0 * atr)
    tp_partial = float(entry * 1.10)
    # position size (shares)
    size_shares = position_size(equity, entry, stop, risk_pct)

    # Determine action: propose an entry when at least trend & breakout & volume & RS filters pass.
    filters = {"trend_ok": trend_ok, "breakout_ok": breakout_ok,
               "volume_ok": volume_ok, "rs_ok": rs_ok}
    all_ok_flag = all(filters.values())
    action = "enter-long" if all_ok_flag else "hold"

    # Build rationale and constraints_check lists
    rationale: List[str] = []
    constraints: List[str] = []
    for key, passed in filters.items():
        if passed:
            constraints.append(key)
        else:
            rationale.append(f"{key.replace('_', ' ')} condition not met")
    if all_ok_flag:
        rationale.append("All entry filters satisfied")

    signal = {
        "ticker": ticker,
        "action": action,
        "entry": round(entry, 2),
        "initial_stop": round(stop, 2),
        "tp_partial": round(tp_partial, 2),
        "trail_rule": "6-8% off highest close",
        "size_shares": size_shares,
        "risk_pct": risk_pct,
        "eos": 0,
        "earnings_date": None,
        "rationale": rationale,
        "constraints_check": constraints
    }
    return signal