"""
Backtesting utilities for the Swing Trader Agent.

This module provides a simple event-driven backtester that exercises the
signal generation logic defined in ``src.signal_engine`` on historical
OHLCV data. The backtester simulates entries and exits based on the
strategy's rules and calculates basic performance statistics.

The backtester assumes long-only trades with partial profit taking at
10% and a fixed risk per trade. For simplicity, it does not model
slippage or transaction costs. The stop loss is set using ATR and
shares are sized according to the 1.5% risk rule. Positions are exited
when either the stop or the target is hit or when 65 trading days
elapse.

Usage example:

```
from src.backtester import run_backtest
from src.live_data import get_ohlcv
from src.signal_engine import generate_signal

universes = {"ai_compute": ["NVDA", "AMD"]}
results = run_backtest(universes, equity=100000.0, risk_pct=0.015)
print(results)
```
"""

from __future__ import annotations

from typing import Dict, List, Tuple, Optional

import pandas as pd

from .live_data import get_ohlcv
from .signal_engine import generate_signal


class Position:
    """Represents an open position in the backtester."""

    def __init__(self, ticker: str, entry_date: pd.Timestamp, entry_price: float,
                 stop_price: float, target_price: float, shares: int):
        self.ticker = ticker
        self.entry_date = entry_date
        self.entry_price = entry_price
        self.stop_price = stop_price
        self.target_price = target_price
        self.shares = shares
        self.days_held = 0
        self.is_closed = False
        self.exit_date: Optional[pd.Timestamp] = None
        self.exit_price: Optional[float] = None
        self.profit: float = 0.0

    def update(self, date: pd.Timestamp, price: float) -> None:
        """Update the position state given today's date and close price.

        Checks for stop/target hit and updates days held. Does not close
        the position automatically on time exit; the caller is responsible
        for closing positions on time stop.
        """
        if self.is_closed:
            return
        self.days_held += 1
        # Check stop
        if price <= self.stop_price:
            self.is_closed = True
            self.exit_date = date
            self.exit_price = self.stop_price  # assume exit at stop price
            self.profit = (self.exit_price - self.entry_price) * self.shares
        # Check target (10% profit); we do full exit for simplicity
        elif price >= self.target_price:
            self.is_closed = True
            self.exit_date = date
            self.exit_price = price
            self.profit = (self.exit_price - self.entry_price) * self.shares


def run_backtest(universes: Dict[str, List[str]], equity: float = 100000.0,
                 risk_pct: float = 0.015, max_hold_days: int = 65) -> Dict[str, object]:
    """Run a backtest over the provided universes.

    Iterates over each ticker's OHLCV data, generates entry signals on a
    daily basis, and simulates trade execution and management. Returns
    summary statistics and trade details.

    Args:
        universes: mapping of theme to list of tickers.
        equity: starting account equity.
        risk_pct: fraction of equity to risk per trade.
        max_hold_days: maximum days to hold a position (time stop).

    Returns:
        Dictionary with summary statistics and list of trade records.
    """
    trades: List[Dict[str, object]] = []
    current_equity = equity

    for theme, tickers in universes.items():
        # Determine benchmark symbol based on theme for RS filter
        if theme == "ai_compute":
            bench_sym = "QQQ"
        elif theme == "infra":
            bench_sym = "SPY"
        elif theme == "nuclear":
            bench_sym = "URNM"
        elif theme == "ev":
            bench_sym = "IWM"
        else:
            bench_sym = "SPY"
        bench_df = get_ohlcv(bench_sym, lookback=600)
        for ticker in tickers:
            df = get_ohlcv(ticker, lookback=600)
            if df.empty or len(df) < 200:
                continue
            # Align benchmark to ticker's dates
            bench = bench_df.reindex(df.index).dropna()
            if len(bench) < 200:
                continue
            open_positions: List[Position] = []
            # Iterate over each day after day 200 (to have enough lookback)
            for i in range(200, len(df)):
                date = df.index[i]
                today_slice = df.iloc[: i + 1]
                bench_slice = bench.iloc[: i + 1]
                # Update existing positions
                close_price = df.iloc[i]["Close"]
                for pos in open_positions:
                    pos.update(date, close_price)
                # Remove closed positions and add to trades
                for pos in open_positions[:]:
                    if pos.is_closed or pos.days_held >= max_hold_days:
                        exit_price = pos.exit_price if pos.exit_price is not None else close_price
                        if not pos.is_closed:
                            # time stop: close at current close price
                            pos.is_closed = True
                            pos.exit_date = date
                            pos.exit_price = exit_price
                            pos.profit = (exit_price - pos.entry_price) * pos.shares
                        trades.append({
                            "ticker": pos.ticker,
                            "entry_date": pos.entry_date.strftime("%Y-%m-%d"),
                            "exit_date": pos.exit_date.strftime("%Y-%m-%d") if pos.exit_date else None,
                            "entry_price": round(pos.entry_price, 2),
                            "exit_price": round(pos.exit_price, 2) if pos.exit_price else None,
                            "shares": pos.shares,
                            "profit": round(pos.profit, 2),
                        })
                        current_equity += pos.profit
                        open_positions.remove(pos)
                # Skip new entries if we already hold a position in this ticker
                if any(not p.is_closed for p in open_positions):
                    continue
                # Generate signal using all data up to today
                sig = generate_signal(ticker, today_slice, bench_slice, current_equity, risk_pct)
                if sig is None:
                    continue
                if sig.get("action") == "enter-long":
                    # Open a new position on next day open (use today's close as proxy)
                    entry_price = close_price
                    shares = sig.get("size_shares", 0)
                    initial_stop = sig.get("initial_stop", entry_price - 0.1)
                    tp = sig.get("tp_partial", entry_price * 1.10)
                    pos = Position(
                        ticker=ticker,
                        entry_date=date,
                        entry_price=entry_price,
                        stop_price=initial_stop,
                        target_price=tp,
                        shares=shares
                    )
                    open_positions.append(pos)
    # Summarize results
    total_profit = sum(t["profit"] for t in trades)
    win_trades = [t for t in trades if t["profit"] > 0]
    loss_trades = [t for t in trades if t["profit"] <= 0]
    win_rate = len(win_trades) / len(trades) if trades else 0
    return {
        "starting_equity": equity,
        "ending_equity": current_equity,
        "total_profit": round(total_profit, 2),
        "number_of_trades": len(trades),
        "win_rate": round(win_rate, 3),
        "trades": trades,
    }