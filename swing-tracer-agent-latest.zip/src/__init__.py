"""
Utility package for the Swing Trader Agent.

The ``src`` package houses modules used by the main orchestration script,
including data fetching and signal generation.  To expose top‑level names for
ease of import, we define ``__all__``.  When adding new modules to this
package, update ``__all__`` accordingly.
"""

from .live_data import get_ohlcv  # noqa: F401
from .signal_engine import generate_signal  # noqa: F401

__all__ = ["get_ohlcv", "generate_signal"]