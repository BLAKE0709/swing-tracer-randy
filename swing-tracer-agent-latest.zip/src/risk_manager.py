"""Risk management utilities for the Swing‑Trader Agent.

This module provides a simple adaptive risk sizing function. The idea is to
reduce per‑trade risk when the account equity has experienced a drawdown
beyond a configurable threshold. The state of the account (peak equity and
latest equity) is persisted to a small JSON file in the project directory,
allowing the agent to carry forward drawdown information between runs.

Functions
---------
get_risk_pct(initial_pct, reduced_pct, drawdown_threshold) -> float
    Compute the per‑trade risk percentage based on the current equity
    relative to the peak equity stored in the state file.

update_equity(new_equity) -> None
    Update the equity state file with the latest equity value. This will
    adjust the stored peak equity if a new high watermark is reached.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any

# Path to the JSON file that stores the current and peak equity. The file is
# located alongside other data files within the project. If the parent
# directory does not exist, it will be created on update.
STATE_FILE = Path(__file__).resolve().parents[1] / "data" / "risk_state.json"

def _load_state() -> Dict[str, Any]:
    """Load the equity state from the JSON file.

    Returns a dictionary containing at least ``peak_equity`` and ``equity``.
    If the file does not exist or is invalid, defaults are used.

    Returns
    -------
    dict
        A dictionary with keys ``peak_equity`` and ``equity``.
    """
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and "peak_equity" in data and "equity" in data:
                return data
        except Exception:
            pass
    # Fallback: start with default equity of 100,000
    return {"peak_equity": 100_000.0, "equity": 100_000.0}


def _save_state(state: Dict[str, Any]) -> None:
    """Persist the equity state to disk.

    Parameters
    ----------
    state : dict
        The state dictionary containing at least ``peak_equity`` and ``equity``.
    """
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f)


def get_risk_pct(
    initial_pct: float = 1.5,
    reduced_pct: float = 1.0,
    drawdown_threshold: float = 0.10,
) -> float:
    """Determine the per‑trade risk percentage based on drawdown.

    The function reads the stored account equity and peak equity from the
    state file. If the drawdown (peak minus current equity divided by peak)
    exceeds the specified threshold, a reduced risk percentage is returned.
    Otherwise, the initial risk percentage is returned.

    Parameters
    ----------
    initial_pct : float
        The default per‑trade risk percentage when the account is within its
        risk budget. Defaults to 1.5 (%).
    reduced_pct : float
        The lower risk percentage applied after the drawdown threshold is
        breached. Defaults to 1.0 (%).
    drawdown_threshold : float
        The maximum allowed drawdown (as a fraction). When the account
        experiences a drawdown greater than this, risk is reduced.

    Returns
    -------
    float
        The per‑trade risk percentage to apply.
    """
    state = _load_state()
    peak = state.get("peak_equity", 100_000.0)
    equity = state.get("equity", 100_000.0)
    if peak <= 0:
        peak = equity if equity > 0 else 100_000.0
    drawdown = (peak - equity) / peak if peak > 0 else 0.0
    return reduced_pct if drawdown > drawdown_threshold else initial_pct


def update_equity(new_equity: float) -> None:
    """Update the equity state with a new account balance.

    This function should be called after trades are closed or at the end of
    a trading session to persist the latest account balance. If the new
    equity exceeds the previously stored peak equity, the peak is updated.

    Parameters
    ----------
    new_equity : float
        The account balance after recent trading activity.
    """
    state = _load_state()
    # Update the peak equity if a new high is reached
    if new_equity > state.get("peak_equity", 0):
        state["peak_equity"] = new_equity
    state["equity"] = new_equity
    _save_state(state)
