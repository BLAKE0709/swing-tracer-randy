"""
Helper module to fetch OHLCV data for tickers.

This implementation provides a stub data generator that produces synthetic
open/high/low/close/volume (OHLCV) time series for a given ticker. In a real
deployment you would replace the stub generator with a call to a market data
provider (e.g. Alpha Vantage, Polygon, Interactive Brokers) or load data from
Google Drive via the available connectors.

Functions:
    get_ohlcv(ticker: str, lookback: int = 252) -> pandas.DataFrame
        Return an OHLCV DataFrame indexed by date. The data covers at least
        ``lookback`` trading days. The DataFrame has columns Open, High,
        Low, Close, and Volume.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from datetime import datetime, timedelta

def _generate_stub_series(n: int, seed: int = None) -> pd.DataFrame:
    """
    Generate a random walk price series with synthetic high/low and volume.

    Args:
        n: number of periods to generate.
        seed: optional random seed to make results reproducible.

    Returns:
        DataFrame with columns Open, High, Low, Close, Volume and a DatetimeIndex.
    """
    rng = np.random.default_rng(seed)
    base_price = 50 + rng.uniform(-5, 5)
    log_rets = rng.normal(loc=0.0005, scale=0.02, size=n)
    prices = base_price * np.exp(np.cumsum(log_rets))
    prices = np.maximum(prices, 0.1)
    high_spread = rng.uniform(0.0, 0.03, size=n)
    low_spread  = rng.uniform(0.0, 0.03, size=n)
    highs = prices * (1.0 + high_spread)
    lows  = prices * (1.0 - low_spread)
    opens = np.roll(prices, 1)
    opens[0] = prices[0]
    volumes = rng.integers(low=1_000_000, high=5_000_000, size=n)
    end_date = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    start_date = end_date - timedelta(days=n)
    idx = pd.date_range(start=start_date, periods=n, freq="D")
    df = pd.DataFrame({
        "Open": opens,
        "High": highs,
        "Low": lows,
        "Close": prices,
        "Volume": volumes
    }, index=idx)
    return df

def get_ohlcv(ticker: str, lookback: int = 252) -> pd.DataFrame:
    """
    Retrieve OHLCV data for ``ticker``.

    This stub implementation generates a synthetic time series. In production,
    replace this with a data fetch from your broker, a local CSV file, or a
    Google Drive connector.

    Args:
        ticker: the symbol to fetch.
        lookback: number of periods (daily bars) to return.

    Returns:
        DataFrame with OHLCV data.
    """
    seed = abs(hash(ticker)) % (2**32)
    df = _generate_stub_series(lookback, seed=seed)
    return df