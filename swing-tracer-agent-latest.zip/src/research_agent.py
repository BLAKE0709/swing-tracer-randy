"""Research Agent Module

This module contains helper functions for the Swing Trader Agent's research
agent.  The research agent surfaces macro, sector and company-specific
insights that are not captured purely by price and volume data.  It can
search connected services (e.g. Google Drive, Gmail) for documents or
emails that mention tickers or themes, perform simple sentiment analysis
on the retrieved text, and synthesize the findings into a brief report.

The functions defined here are largely placeholders — they illustrate
where and how to integrate third‑party data sources using the API tool.
Actual network calls require the appropriate connectors to be enabled and
may need authentication tokens; those details should be passed via
environment variables or configuration files.
"""

from __future__ import annotations

import os
import json
from typing import List, Dict

import re

# Base URL for the local API tool.  This is available at runtime when
# using the browser-based environment.  In a deployed environment you
# may need to adjust this endpoint.
API_BASE = os.environ.get("API_TOOL_BASE", "http://localhost:8674")


def _call_api(endpoint: str, params: Dict[str, str]) -> Dict[str, object]:
    """Internal helper to perform a GET request against the API tool.

    Args:
        endpoint: the API endpoint name as returned by search_available_apis.
        params: dictionary of query parameters to encode.

    Returns:
        Parsed JSON response from the API tool.
    """
    import urllib.parse
    import urllib.request
    query = urllib.parse.urlencode(params)
    url = f"{API_BASE}/call_api?name={urllib.parse.quote(endpoint)}&params={urllib.parse.quote(json.dumps(params))}"
    with urllib.request.urlopen(url) as resp:
        data = resp.read().decode("utf-8")
        return json.loads(data)


def search_gmail(query: str, max_results: int = 3) -> List[str]:
    """Search the connected Gmail inbox for emails matching the query.

    This uses the ``/search_emails`` endpoint exposed by the Gmail connector.
    It returns the subject lines of up to ``max_results`` matching emails.
    
    Args:
        query: Gmail search string, e.g. "NVDA earnings".
        max_results: maximum number of emails to return.

    Returns:
        List of email subject snippets.
    """
    endpoint = "/connector_2128aebfecb84f64a069897515042a44/search_emails"
    params = {"query": query}
    try:
        data = _call_api(endpoint, params)
        messages = data.get("messages", [])
        subjects = []
        for msg in messages[:max_results]:
            header = msg.get("snippet") or msg.get("subject") or ""
            subjects.append(header)
        return subjects
    except Exception:
        return []


def search_drive_documents(query: str, max_results: int = 3) -> List[str]:
    """Search Google Drive for documents mentioning the query.

    Uses the Google Drive connector's search endpoint to find files whose
    names or contents match the query.  Only returns the file names.

    Args:
        query: search term, e.g. "Uranium market report".
        max_results: number of document names to return.

    Returns:
        List of document titles.
    """
    endpoint = "/connector_71291b5bce3c4ecfb0e40ad2a21b53ce/search_files"
    params = {"query": query}
    try:
        data = _call_api(endpoint, params)
        files = data.get("files", [])
        names = [f.get("name", "Unnamed") for f in files[:max_results]]
        return names
    except Exception:
        return []


def simple_sentiment(text: str) -> float:
    """Compute a rudimentary sentiment score for the given text.

    Counts occurrences of positive and negative words to derive a score
    between -1 and 1.  This is a placeholder; for a more robust model
    consider integrating a pre-trained sentiment classifier.

    Args:
        text: raw text to analyze.

    Returns:
        Sentiment polarity in [-1, 1].
    """
    positive = ["good", "great", "strong", "bullish", "positive", "buy", "beat"]
    negative = ["bad", "weak", "bearish", "negative", "sell", "miss"]
    text = text.lower()
    pos_hits = sum(text.count(w) for w in positive)
    neg_hits = sum(text.count(w) for w in negative)
    total = pos_hits + neg_hits
    if total == 0:
        return 0.0
    score = (pos_hits - neg_hits) / total
    return max(-1.0, min(1.0, score))


def compile_research_for_ticker(ticker: str) -> Dict[str, object]:
    """Gather research snippets and sentiment for a single ticker.

    Performs Gmail and Drive searches, computes sentiment scores, and
    aggregates the results.  The returned dictionary can be used to
    augment the daily report or to inform the Exceptional Opportunity
    Score (EOS).

    Args:
        ticker: stock symbol, e.g. "NVDA".

    Returns:
        Dict containing subjects, documents, and an aggregate sentiment.
    """
    # Search emails mentioning the ticker
    email_subjects = search_gmail(f"{ticker} earnings")
    # Search Drive documents mentioning the ticker
    drive_docs = search_drive_documents(ticker)
    # Aggregate all text to compute sentiment
    text_corpus = " ".join(email_subjects + drive_docs)
    sentiment_score = simple_sentiment(text_corpus)
    return {
        "ticker": ticker,
        "email_subjects": email_subjects,
        "drive_documents": drive_docs,
        "sentiment": sentiment_score,
    }