import pandas as pd

def rs_ratio(price: pd.Series, benchmark: pd.Series) -> pd.Series:
    aligned = pd.concat([price, benchmark], axis=1).dropna()
    aligned.columns = ["price","bench"]
    return (aligned["price"] / aligned["bench"]).reindex(price.index)

def rs_signal(rs: pd.Series, ma_len: int=50) -> pd.Series:
    return (rs > rs.rolling(ma_len).mean()).fillna(False)
