import pandas as pd
from datetime import datetime, timedelta

def within_blackout(ticker: str, today: pd.Timestamp, earnings_df: pd.DataFrame, blackout_days: int) -> bool:
    row = earnings_df[earnings_df['ticker']==ticker]
    if row.empty:
        return False
    edate = pd.to_datetime(row.iloc[0]['earnings_date'])
    return abs((edate - today).days) <= blackout_days
