def eos_score(rs_top_decile: bool, volume_top_decile: bool, near_high: bool, 
              multi_month_base: bool, inst_accumulation: bool, weights: dict) -> int:
    score = 0
    score += weights.get("rs_top_decile",3) if rs_top_decile else 0
    score += weights.get("volume_top_decile",2) if volume_top_decile else 0
    score += weights.get("near_high",2) if near_high else 0
    score += weights.get("multi_month_base",2) if multi_month_base else 0
    score += weights.get("inst_accumulation",1) if inst_accumulation else 0
    return score
