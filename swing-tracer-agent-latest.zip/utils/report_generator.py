import json, pandas as pd
from datetime import datetime

def save_daily_signals_json(path, signals:list):
    with open(path, 'w') as f:
        json.dump(signals, f, indent=2)

def save_daily_report_md(path, signals:list, risk_summary:dict):
    ts = datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')
    lines = [f"# Daily Signals — {ts}", "", "## Signals", ""]
    if not signals:
        lines.append("No signals today.")
    else:
        for s in signals:
            lines.append(f"- **{s['ticker']}** | theme: {s['theme']} | entry: {s['entry']:.2f} | stop: {s['initial_stop']:.2f} | TP10: {s['tp_partial']:.2f} | size: {s['size_shares']}")
            lines.append("  rationale: " + "; ".join(s.get('rationale', [])))
    lines += ["", "## Risk Summary", "", json.dumps(risk_summary, indent=2)]
    with open(path, 'w') as f:
        f.write("\n".join(lines))
