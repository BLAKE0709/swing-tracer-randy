"""Daily orchestration for the Agentic Profit-First Swing Trader.

This is a skeleton that:
1) loads configs
2) (placeholder) loads data
3) runs simple signal scaffolding
4) writes reports

Replace the data-loading stubs with your chosen data source (e.g., yfinance/Polygon/IBKR).

"""
import json, os, sys
from pathlib import Path
from datetime import datetime
import pandas as pd

from utils.sizing import position_size
from utils.report_generator import save_daily_signals_json, save_daily_report_md

# Before importing from the 'src' package, ensure the project root is on the
# Python path.  ``main.py`` lives inside the ``swing-trader-agent`` folder,
# which contains a ``src`` package.  By adding the directory containing
# ``main.py`` to ``sys.path`` we can import ``src.live_data`` and
# ``src.signal_engine`` located in the same project.  Without this, Python
# might inadvertently resolve a different ``src`` package (e.g., a sibling
# directory), leading to confusing import errors.
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.live_data import get_ohlcv
from src.signal_engine import generate_signal
# Import risk management functions. These functions adjust per‑trade risk
# based on the account's drawdown and persist the latest equity state. If
# risk_manager.py is absent (e.g., older versions), fall back to static risk.
try:
    from src.risk_manager import get_risk_pct, update_equity  # type: ignore
except ImportError:
    def get_risk_pct(initial_pct: float = 1.5, reduced_pct: float = 1.0, drawdown_threshold: float = 0.10) -> float:
        return initial_pct
    def update_equity(new_equity: float) -> None:
        pass

ROOT = Path(__file__).parent

def load_json(p): 
    with open(p, 'r') as f: 
        return json.load(f)

def load_universe():
    cfg = ROOT / "config"
    universes = {
        "ai_compute": (cfg / "universe_ai_compute.csv").read_text().strip().splitlines(),
        "infra": (cfg / "universe_infra.csv").read_text().strip().splitlines(),
        "nuclear": (cfg / "universe_nuclear.csv").read_text().strip().splitlines(),
        "ev": (cfg / "universe_ev.csv").read_text().strip().splitlines(),
    }
    return universes

def stub_latest_price(ticker:str) -> float:
    # TODO: replace with real price fetch
    # A harmless deterministic stub to allow the pipeline to run
    return float(abs(hash(ticker)) % 5000) / 100.0 + 10.0

def run() -> None:
    """Main entry point for the daily swing trader pipeline.

    This function orchestrates the generation of trading signals. It loads
    universes and parameters, determines the risk per trade based on
    drawdown, fetches historical OHLCV data for each ticker and its
    benchmark, generates signals via the ``signal_engine``, writes
    structured outputs, and persists the current equity state.
    """
    params = load_json(ROOT / "config/parameters.json")
    eos_rules = load_json(ROOT / "config/eos_rules.json")

    universes = load_universe()

    # Placeholder equity value; in practice this would be fetched from your
    # brokerage account. It is also persisted via update_equity for
    # drawdown tracking.
    equity = 100_000.0

    # Convert risk parameters from fractional form (e.g., 0.015) to
    # percentage points for the risk manager, then divide back to fraction
    # when passing into the sizing functions.
    initial_pct = params.get("risk_per_trade", 0.015) * 100.0
    reduced_pct = params.get("reduced_risk_per_trade", 0.01) * 100.0
    drawdown_threshold = params.get("drawdown_threshold", 0.10)
    risk_pct = get_risk_pct(initial_pct, reduced_pct, drawdown_threshold) / 100.0

    time_now = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

    signals: list[dict] = []

    for theme, tickers in universes.items():
        if not tickers:
            continue
        # Map themes to a default benchmark. This mapping can be refined later.
        if theme == "ai_compute":
            benchmark_symbol = "QQQ"
        elif theme == "infra":
            benchmark_symbol = "SPY"
        elif theme == "nuclear":
            benchmark_symbol = "URNM"
        elif theme == "ev":
            benchmark_symbol = "IWM"
        else:
            benchmark_symbol = "SPY"
        bench_df = get_ohlcv(benchmark_symbol, lookback=300)
        for t in tickers:
            df = get_ohlcv(t, lookback=300)
            sig = generate_signal(t, df, bench_df, equity, risk_pct)
            if sig is None:
                continue
            sig["theme"] = theme
            sig["benchmark"] = benchmark_symbol
            signals.append(sig)
            # stop adding new positions when max position limit reached
            if len([s for s in signals if s["action"] == "enter-long"]) >= params.get("max_positions", 12):
                break

    # write outputs
    (ROOT / "signals").mkdir(exist_ok=True, parents=True)
    (ROOT / "reports").mkdir(exist_ok=True, parents=True)

    save_daily_signals_json(ROOT / "signals/daily_signals.json", signals)
    risk_summary = {
        "equity": equity,
        "max_positions": params.get("max_positions", 12),
        "open_risk_pct": risk_pct,
    }
    save_daily_report_md(ROOT / "reports/daily_report.md", signals, risk_summary)

    # Update risk state with the current equity. In a real implementation,
    # this would be called with the end‑of‑day account balance. Here we
    # simply pass the placeholder equity so the state file exists.
    update_equity(equity)

    print(f"[{time_now}] Wrote {len(signals)} signals to signals/daily_signals.json and reports/daily_report.md")

if __name__ == "__main__":
    run()
